import numpy as np
import pandas as pd
import re
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.ensemble import (RandomForestClassifier, GradientBoostingClassifier,
                              AdaBoostClassifier, ExtraTreesClassifier)
from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, classification_report

# Load dataset
file_path = r"E:\NRC_MODEL_DEV\Spam_Classifier_model\Dataset\emails.csv"
df = pd.read_csv(file_path)

# Display column names to verify correct field names
print("Dataset Columns:", df.columns.tolist())

# Identify correct text and label columns dynamically
text_column = None
label_column = None
for col in df.columns:
    if "text" in col.lower() or "message" in col.lower():
        text_column = col
    if "label" in col.lower() or "spam" in col.lower():
        label_column = col

if text_column is None or label_column is None:
    raise ValueError("Could not automatically detect the text or label column. Please verify column names.")

# Exploratory Data Analysis (EDA)
print("Dataset Head:")
print(df.head())
print("\nMissing Values:")
print(df.isnull().sum())
print("\nClass Distribution:")
print(df[label_column].value_counts())

# Visualizing class distribution
sns.countplot(x=df[label_column])
plt.title("Spam vs Ham Distribution")
plt.show()

# Preprocessing - Text Cleaning and TF-IDF Vectorization
def clean_text(text):
    text = str(text).lower()
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    return text

df["cleaned_text"] = df[text_column].apply(clean_text)
vectorizer = TfidfVectorizer(max_features=5000)
X = vectorizer.fit_transform(df["cleaned_text"])
y = df[label_column]

# Feature Importance using Random Forest
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X, y)
feature_importance = rf.feature_importances_
feature_names = vectorizer.get_feature_names_out()
feature_df = pd.DataFrame({"Feature": feature_names, "Importance": feature_importance})
feature_df = feature_df.sort_values(by="Importance", ascending=False)

# Visualizing top 20 important features
plt.figure(figsize=(10,5))
sns.barplot(x=feature_df["Importance"][:20], y=feature_df["Feature"][:20])
plt.title("Top 20 Important Features")
plt.show()

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define models
models = {
    "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42),
    "Gradient Boosting": GradientBoostingClassifier(n_estimators=100, random_state=42),
    "Support Vector Machine": SVC(kernel='linear', random_state=42),
    "Naive Bayes": MultinomialNB(),
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
    "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=5),
    "AdaBoost": AdaBoostClassifier(n_estimators=100, random_state=42)
}

# Train and evaluate models
results = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    results[name] = {
        "Accuracy": accuracy,
        "Report": classification_report(y_test, y_pred, output_dict=True)
    }

# Best model selection
best_model = max(results, key=lambda k: results[k]["Accuracy"])
final_model = models[best_model]

# Print best model details
print(f"Best Model: {best_model}")
print(f"Accuracy: {results[best_model]['Accuracy']:.2%}")
print("Classification Report:")
print(classification_report(y_test, final_model.predict(X_test)))
